# Gestão Escolar — Starter (Flutter Web + NestJS + Postgres)

Este repositório é um **esqueleto inicial** para uma Web App de gestão escolar:
- **Frontend**: Flutter Web (Dart) — UI responsiva (mobile-first)
- **Backend**: NestJS (TypeScript) — API REST + Auth JWT + RBAC básico
- **DB**: PostgreSQL + Prisma
- **Docker**: docker-compose para backend + DB (dev)

## Estrutura
- `frontend/` — Flutter Web
- `backend/` — NestJS API
- `docker-compose.yml` — Postgres + backend

---

## Como executar (DEV)

### 1) Backend + DB via Docker
> Requisitos: Docker + Docker Compose

```bash
docker compose up --build
```

- API: `http://localhost:3000`
- Swagger: `http://localhost:3000/docs`
- Postgres: `localhost:5432` (user: `postgres`, pass: `postgres`, db: `gestao_escolar`)

### 2) Frontend Flutter Web (local)
> Requisitos: Flutter instalado (Android Studio serve)

```bash
cd frontend
flutter pub get
flutter run -d chrome
```

Por padrão, o Flutter está configurado para chamar a API em `http://localhost:3000`.

---

## Contas de teste (Seed)
Ao subir o backend, um seed cria:
- **admin**: `admin@escola.local` / `Admin@123`
- **secretaria**: `sec@escola.local` / `Sec@12345`
- **professor**: `prof@escola.local` / `Prof@12345`
- **financeiro**: `fin@escola.local` / `Fin@12345`

> Podes mudar no `backend/prisma/seed.ts`.

---

## Próximos módulos (roadmap curto)
1. CRUD Alunos / Funcionários (com paginação + pesquisa)
2. Ano lectivo, turmas, disciplinas
3. Matrículas
4. Notas por trimestre + avaliações
5. Horários (validação de conflitos)
6. Financeiro (cobranças/pagamentos em KZ)
7. Boletins (PDF A4) — endpoint `GET /reports/report-card/:studentId?term=1`

---

## Notas importantes
- O RBAC aqui é **básico**, mas já vem com `RolesGuard`.
- O PDF de boletim está preparado como placeholder. Vamos preencher quando entrares no módulo de notas.
