import { PrismaClient, UserRole } from "@prisma/client";
import * as bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function upsertUser(email: string, name: string, password: string, role: UserRole) {
  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.upsert({
    where: { email },
    update: { name, passwordHash, role, isActive: true },
    create: { email, name, passwordHash, role }
  });
}

async function main() {
  await upsertUser("admin@escola.local", "Admin", "Admin@123", UserRole.ADMIN);
  await upsertUser("sec@escola.local", "Secretaria", "Sec@12345", UserRole.SECRETARIA);
  await upsertUser("prof@escola.local", "Professor", "Prof@12345", UserRole.PROFESSOR);
  await upsertUser("fin@escola.local", "Financeiro", "Fin@12345", UserRole.FINANCEIRO);

  // seed de exemplo: 2 alunos
  await prisma.student.upsert({
    where: { id: "00000000-0000-0000-0000-000000000001" },
    update: {},
    create: { id: "00000000-0000-0000-0000-000000000001", fullName: "João Manuel", phone: "900000001" }
  });
  await prisma.student.upsert({
    where: { id: "00000000-0000-0000-0000-000000000002" },
    update: {},
    create: { id: "00000000-0000-0000-0000-000000000002", fullName: "Maria Fernanda", phone: "900000002" }
  });
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    return prisma.$disconnect().finally(() => process.exit(1));
  });
