import { Injectable, NotFoundException } from "@nestjs/common";
import PDFDocument from "pdfkit";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class ReportsService {
  constructor(private readonly prisma: PrismaService) {}

  async generateReportCard(studentId: string, term: 1 | 2 | 3) {
    const student = await this.prisma.student.findUnique({ where: { id: studentId } });
    if (!student) throw new NotFoundException("Aluno não encontrado");

    // Placeholder: quando entrares no módulo de notas, vais buscar disciplinas/avaliações aqui.
    const items = [
      { subject: "Matemática", grade: "—" },
      { subject: "Português", grade: "—" },
      { subject: "Ciências", grade: "—" },
    ];

    const doc = new PDFDocument({ size: "A4", margin: 48 });

    // Cabeçalho
    doc.fontSize(16).text("BOLETIM DE NOTAS", { align: "center" });
    doc.moveDown(0.5);
    doc.fontSize(11).text("Escola: ________________________________");
    doc.text(`Aluno: ${student.fullName}`);
    doc.text(`Trimestre: ${term}º`);
    doc.text(`Data de emissão: ${new Date().toLocaleDateString("pt-PT")}`);
    doc.moveDown();

    // Tabela simples
    doc.fontSize(12).text("Disciplinas", { underline: true });
    doc.moveDown(0.5);

    items.forEach((it) => {
      doc.fontSize(11).text(`${it.subject}: ${it.grade}`);
    });

    doc.moveDown(2);
    doc.text("Assinatura: ____________________________", { align: "left" });

    return doc;
  }
}
