# Frontend — Flutter Web

## Executar
```bash
flutter pub get
flutter run -d chrome
```

## Configurar API
Por padrão a API está em `http://localhost:3000`.

Se quiseres, podes compilar com:
```bash
flutter run -d chrome --dart-define=API_BASE_URL=http://localhost:3000
```
