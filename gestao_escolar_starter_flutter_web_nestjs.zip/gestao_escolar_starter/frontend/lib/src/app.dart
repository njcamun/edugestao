import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/auth/login_page.dart';
import 'features/dashboard/dashboard_page.dart';
import 'features/students/students_page.dart';
import 'shared/responsive_scaffold.dart';
import 'state/session.dart';

class App extends ConsumerWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = _router(ref);

    return MaterialApp.router(
      title: 'Gestão Escolar',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      routerConfig: router,
    );
  }

  GoRouter _router(WidgetRef ref) {
    return GoRouter(
      initialLocation: '/login',
      refreshListenable: ref.read(sessionProvider.notifier),
      redirect: (context, state) {
        final session = ref.read(sessionProvider);

        final isLoggingIn = state.matchedLocation == '/login';
        if (session.isAuthenticated && isLoggingIn) return '/';
        if (!session.isAuthenticated && !isLoggingIn) return '/login';
        return null;
      },
      routes: [
        GoRoute(
          path: '/login',
          builder: (_, __) => const LoginPage(),
        ),
        ShellRoute(
          builder: (context, state, child) => ResponsiveScaffold(child: child),
          routes: [
            GoRoute(
              path: '/',
              builder: (_, __) => const DashboardPage(),
            ),
            GoRoute(
              path: '/students',
              builder: (_, __) => const StudentsPage(),
            ),
          ],
        ),
      ],
    );
  }
}
