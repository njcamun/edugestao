import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../state/session.dart';

class StudentsPage extends ConsumerStatefulWidget {
  const StudentsPage({super.key});

  @override
  ConsumerState<StudentsPage> createState() => _StudentsPageState();
}

class _StudentsPageState extends ConsumerState<StudentsPage> {
  final _q = TextEditingController();
  int _page = 1;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      // trigger rebuild; data is fetched via FutureBuilder
    } catch (e) {
      setState(() => _error = 'Falha ao carregar alunos.');
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final api = ref.watch(apiClientProvider);

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Alunos', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _q,
                  decoration: const InputDecoration(
                    labelText: 'Pesquisar por nome',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onSubmitted: (_) => setState(() => _page = 1),
                ),
              ),
              const SizedBox(width: 12),
              FilledButton.icon(
                onPressed: _loading ? null : () => setState(() => _page = 1),
                icon: const Icon(Icons.refresh),
                label: const Text('Actualizar'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
          Expanded(
            child: FutureBuilder(
              future: api.listStudents(q: _q.text.trim().isEmpty ? null : _q.text.trim(), page: _page, pageSize: 10),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return const Center(child: Text('Erro ao carregar.'));
                }
                final data = snapshot.data!;
                return Card(
                  child: Column(
                    children: [
                      Expanded(
                        child: ListView.separated(
                          itemCount: data.items.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (_, i) {
                            final s = data.items[i];
                            return ListTile(
                              leading: const Icon(Icons.person),
                              title: Text(s.fullName),
                              subtitle: Text(s.phone ?? 'Sem contacto'),
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Total: ${data.total}'),
                            Row(
                              children: [
                                IconButton(
                                  onPressed: _page <= 1 ? null : () => setState(() => _page -= 1),
                                  icon: const Icon(Icons.chevron_left),
                                ),
                                Text('Página $_page'),
                                IconButton(
                                  onPressed: (_page * data.pageSize) >= data.total ? null : () => setState(() => _page += 1),
                                  icon: const Icon(Icons.chevron_right),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
