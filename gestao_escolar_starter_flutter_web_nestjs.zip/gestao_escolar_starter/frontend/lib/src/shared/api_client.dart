import 'package:dio/dio.dart';

class LoginUserDto {
  final String id;
  final String email;
  final String name;
  final String role;

  LoginUserDto({required this.id, required this.email, required this.name, required this.role});

  factory LoginUserDto.fromJson(Map<String, dynamic> json) => LoginUserDto(
    id: json['id'] as String,
    email: json['email'] as String,
    name: json['name'] as String,
    role: json['role'] as String,
  );
}

class LoginResponseDto {
  final String accessToken;
  final String refreshToken;
  final LoginUserDto user;

  LoginResponseDto({required this.accessToken, required this.refreshToken, required this.user});

  factory LoginResponseDto.fromJson(Map<String, dynamic> json) => LoginResponseDto(
    accessToken: json['accessToken'] as String,
    refreshToken: json['refreshToken'] as String,
    user: LoginUserDto.fromJson(json['user'] as Map<String, dynamic>),
  );
}

class StudentDto {
  final String id;
  final String fullName;
  final String? phone;

  StudentDto({required this.id, required this.fullName, this.phone});

  factory StudentDto.fromJson(Map<String, dynamic> json) => StudentDto(
    id: json['id'] as String,
    fullName: json['fullName'] as String,
    phone: json['phone'] as String?,
  );
}

class PaginatedStudentsDto {
  final List<StudentDto> items;
  final int total;
  final int page;
  final int pageSize;

  PaginatedStudentsDto({required this.items, required this.total, required this.page, required this.pageSize});

  factory PaginatedStudentsDto.fromJson(Map<String, dynamic> json) => PaginatedStudentsDto(
    items: (json['items'] as List).map((e) => StudentDto.fromJson(e as Map<String, dynamic>)).toList(),
    total: json['total'] as int,
    page: json['page'] as int,
    pageSize: json['pageSize'] as int,
  );
}

class ApiClient {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: const String.fromEnvironment('API_BASE_URL', defaultValue: 'http://localhost:3000'),
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 20),
  ));

  ApiClient() {
    _dio.interceptors.add(InterceptorsWrapper(
      onError: (e, handler) {
        handler.next(e);
      },
    ));
  }

  void setAccessToken(String? token) {
    if (token == null) {
      _dio.options.headers.remove('Authorization');
    } else {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    }
  }

  Future<LoginResponseDto> login(String email, String password) async {
    final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    return LoginResponseDto.fromJson(res.data as Map<String, dynamic>);
  }

  Future<PaginatedStudentsDto> listStudents({String? q, int page = 1, int pageSize = 20}) async {
    final res = await _dio.get('/students', queryParameters: {'q': q, 'page': page, 'pageSize': pageSize});
    return PaginatedStudentsDto.fromJson(res.data as Map<String, dynamic>);
  }
}
