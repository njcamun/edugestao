import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../state/session.dart';

class ResponsiveScaffold extends ConsumerWidget {
  final Widget child;
  const ResponsiveScaffold({super.key, required this.child});

  static const _breakpoint = 900.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final width = MediaQuery.of(context).size.width;
    final isDesktop = width >= _breakpoint;

    final items = <_NavItem>[
      _NavItem(label: 'Dashboard', icon: Icons.dashboard, route: '/'),
      _NavItem(label: 'Alunos', icon: Icons.school, route: '/students'),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestão Escolar'),
        actions: [
          IconButton(
            tooltip: 'Sair',
            onPressed: () => ref.read(sessionProvider.notifier).logout(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      drawer: isDesktop ? null : Drawer(child: _DrawerNav(items: items)),
      body: Row(
        children: [
          if (isDesktop) SizedBox(width: 260, child: _SidebarNav(items: items)),
          Expanded(child: child),
        ],
      ),
      bottomNavigationBar: isDesktop ? null : _BottomNav(items: items),
    );
  }
}

class _NavItem {
  final String label;
  final IconData icon;
  final String route;
  const _NavItem({required this.label, required this.icon, required this.route});
}

class _SidebarNav extends StatelessWidget {
  final List<_NavItem> items;
  const _SidebarNav({required this.items});

  @override
  Widget build(BuildContext context) {
    final current = ModalRoute.of(context)?.settings.name;
    return Material(
      elevation: 1,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text('Menu', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
          ...items.map((it) => ListTile(
                leading: Icon(it.icon),
                title: Text(it.label),
                selected: current == it.route,
                onTap: () => Navigator.of(context).pushReplacementNamed(it.route),
              )),
        ],
      ),
    );
  }
}

class _DrawerNav extends StatelessWidget {
  final List<_NavItem> items;
  const _DrawerNav({required this.items});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const DrawerHeader(child: Text('Gestão Escolar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
        ...items.map((it) => ListTile(
              leading: Icon(it.icon),
              title: Text(it.label),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacementNamed(it.route);
              },
            )),
      ],
    );
  }
}

class _BottomNav extends StatefulWidget {
  final List<_NavItem> items;
  const _BottomNav({required this.items});

  @override
  State<_BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<_BottomNav> {
  int idx = 0;

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: idx,
      onDestinationSelected: (i) {
        setState(() => idx = i);
        Navigator.of(context).pushReplacementNamed(widget.items[i].route);
      },
      destinations: widget.items
          .map((it) => NavigationDestination(icon: Icon(it.icon), label: it.label))
          .toList(),
    );
  }
}
