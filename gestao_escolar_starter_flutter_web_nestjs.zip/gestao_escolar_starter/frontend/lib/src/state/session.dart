import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../shared/api_client.dart';

@immutable
class SessionState {
  final bool isAuthenticated;
  final String? accessToken;
  final String? email;
  final String? role;

  const SessionState({
    required this.isAuthenticated,
    this.accessToken,
    this.email,
    this.role,
  });

  const SessionState.anonymous() : this(isAuthenticated: false);

  SessionState authenticated({
    required String accessToken,
    required String email,
    required String role,
  }) {
    return SessionState(
      isAuthenticated: true,
      accessToken: accessToken,
      email: email,
      role: role,
    );
  }
}

class SessionNotifier extends ChangeNotifier {
  SessionState _state = const SessionState.anonymous();
  final ApiClient api;

  SessionNotifier(this.api);

  SessionState get state => _state;
  bool get isAuthenticated => _state.isAuthenticated;

  Future<void> login(String email, String password) async {
    final res = await api.login(email, password);
    _state = _state.authenticated(
      accessToken: res.accessToken,
      email: res.user.email,
      role: res.user.role,
    );
    api.setAccessToken(_state.accessToken!);
    notifyListeners();
  }

  void logout() {
    _state = const SessionState.anonymous();
    api.setAccessToken(null);
    notifyListeners();
  }
}

final apiClientProvider = Provider<ApiClient>((ref) => ApiClient());

final sessionProvider = ChangeNotifierProvider<SessionNotifier>((ref) {
  final api = ref.watch(apiClientProvider);
  return SessionNotifier(api);
});
